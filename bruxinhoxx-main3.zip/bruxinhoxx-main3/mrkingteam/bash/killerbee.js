const killerbee = (prefix) => { 
	return `
	
	*Cara! Este recurso ainda está em desenvolvimento, aguarde a última versão da atualização do ANJOS BOT...*
	

⧿⧽ *Não se esqueça de se inscrever*
⧿⧽ *Ative os sinos*
⧿⧽ *Saudações anjos*

`
}
exports.killerbee = killerbee

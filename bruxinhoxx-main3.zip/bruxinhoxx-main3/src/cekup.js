const cekup = (prefix) => { 

	return `
	
「 *ATUALIZANDO* 」

TODOS OS RECURSOS DE NOTÍCIAS
ENCONTRAR UM BUG?
MODELO *${prefix}laporbug*
RECURSOS DO FILTRO?
MODELO *${prefix}reqwest*


*NOTE :*

[❗]  *INSCREVA-SE NO INSTAGRAM*

 
`

}

exports.cekup = cekup
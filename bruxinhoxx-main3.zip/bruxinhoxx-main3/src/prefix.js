const cekprefix = (prefix) => { 
	return `
	PREFIXOS ATUALMENTE USADOS *「* ${prefix} *」
	`
	}
exports.cekprefix = cekprefix
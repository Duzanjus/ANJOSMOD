const memobot = (prefix) => { 
	return `
	
╭──「 *ANJOS BOT* 」
┃
├ ANJOS BOT = V1. 0.00.00
┃
╰─────────────────╯

`

}

exports.memobot = memobot


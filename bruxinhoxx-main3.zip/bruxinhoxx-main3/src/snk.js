const snk = () => { 
	return `Termos e Condições do BOT ANJOS
1. Não armazenamos fotos, vídeos, arquivos, áudios e documentos que você envia
2. Nunca pediremos que você forneça informações pessoais
3. Se você encontrar um bug / erro, informe diretamente ao proprietário do bot
4. O que quer que você peça neste bot, NÃO SEREMOS RESPONSÁVEIS!

OBRIGADO 😀❤️ !`
}
exports.snk = snk

const rules = (prefix) => { 
	return `
*REGRAS PARA AMBOS OS USUÁRIOS*
    
➤ Use o atraso, não envie spam ao usar bots, batatas grátis são todas empurradas.
➤ Bloqueio automático do bot de chamada / VC.
➤ Não chame / bot VC se não estiver ativo.
➤ O bot não fica ativo 24 horas, então depende se o proprietário está lá quando o bot também está ativado.
➤ Não armazenamos fotos, vídeos, arquivos, áudios e documentos que você envia
➤ Nunca pediremos que você forneça informações pessoais
➤ Se você encontrar um bug / erro, informe diretamente ao proprietário do bot
➤ O que quer que você peça neste bot, NÃO SEREMOS RESPONSÁVEIS!

*Consequências por violar regras*
*O bot irá bloquear você ou sair do grupo que você gerencia.*
*Essas regras são para o conforto de todos que usam*
*Este bot :*

1. Não envie spam para bots. 
Pena: *AVISO/BLOCK SUAVE*

2. Não chame bots.
Pena: *BLOCK SUAVE*

3. Não explore bots.
Sanksi: *PERMANENTE BLOCK*

Se as regras forem compreendidas, digite *${prefix}menu* para iniciar!

──「 *ANJOS BOT* 」──`
}
exports.rules = rules
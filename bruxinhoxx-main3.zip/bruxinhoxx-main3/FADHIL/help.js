const help = (prefix, instagram, yt, name, pushname2, user, limitt) => { 
	return `

╭───────────────────
┃╭─────────────────
┃├➲ \`\`\`SALVE\`\`\`👋 *${pushname2}*
┃├➲ \`\`\`Seu limite :\`\`\` *${limitt}*
┃├➲ \`\`\`Verificação.   :\`\`\` *SIM*
┃├➲ \`\`\`Premium.   :\`\`\` *NAO*
┃├➲ \`\`\`Total de usuários :\`\`\` *${user.length} User*
┃╰─────────────────
┃
┃╭───「 *LISTA MENU* 」───
┃├❍ *${prefix}listamenu*
┃├❍ *${prefix}midiamenu*
┃├❍ *${prefix}criadormenu*
┃├❍ *${prefix}grupomenu*
┃├❍ *${prefix}makermenu*
┃├❍ *${prefix}funmenu*
┃├❍ *${prefix}nsfwmenu*
┃├❍ *${prefix}onwermenu*
┃╰─────────────────
┃
┃╭─────「 *ABOUT* 」───
┃├❍ *${prefix}info*
┃├❍ *${prefix}donasi*
┃├❍ *${prefix}owner*
┃├❍ *${prefix}speed*
┃├❍ *${prefix}daftar*
┃├❍ *${prefix}totaluser*
┃├❍ *${prefix}chatlist*
┃├❍ *${prefix}grouplist*
┃├❍ *${prefix}blocklist*
┃├❍ *${prefix}banlist*
┃├❍ *${prefix}bahasa*
┃╰─────────────────


         *© ANJOS MODS*
╲    ╱    ● ᏴϴͲ●ᎷᎬΝႮ●
       ╱▔▔▔▔▔╲       Autor    : ANJOS
      ┃┈▇┈┈▇┈┃      
╭╮┣━━━━━━┫╭╮    
┃┃┃┈┈┈┈┈┈┃┃┃    
╰╯┃┈┈┈┈┈┈┃╰╯
      ╰┓┏━━┓┏╯
         ╰╯      ╰╯`
}
exports.help = help

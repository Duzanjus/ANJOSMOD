const donasi = (Ig, name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DOAR o mais rápido possível:)* ❉⊰━━✿
┃  
┣━⊱ *Doação*
┣⊱ SOMENTE PARA O PROPRIETÁRIO ANJOS
┣━⊱ *Premium*
┣⊱ (5 REAIS) +5511932300710
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY ANJOS MODS*
┗━━━━━━━━━━━━━━━━━━━━
Nota:
Se você doar pelo menos siga IG: memes_tataco
Se você doar, convide seu grupo :)
Obrigado:)


${Ig}

`
}

exports.donasi = donasi

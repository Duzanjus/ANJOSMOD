const rules = (name, uptime, tanggal, jam, prefix) => {
return `

 CULTURA LENDO PARA NÃO FICAR Confuso.
╭───────────────────────
├➲ \`\`\`ATIVO\`\`\`: *${kyun(uptime)}*
├➲ \`\`\`Horario\`\`\`: *${jam} WIB*
├➲ \`\`\`ENCONTRO\`\`\`: *${tanggal}*
├➲ \`\`\`VERSÃO\`\`\`: 99999 TERMUX*
╰───────────────────────
 *「RULES ${name}」*
 
➲ ⚠️SPAM.⚠️      = *BANNED + BLOCK*
➲ ⚠️*CALL / VC⚠️ = *BANNED + BLOCK*

 *「BUGS ${name}」*

➲ *1.CHATLIST*
➲ *2.CNEON*
➲ *3.CNEON2*
➲ *4.TRIGGER*
➲ *5.WASTED*
➲ *6.C3D*
➲ *7.SIMI*
➲ *8.GETSES*

 *「 NOTE ${name} 」*
 
➲ Este bot é um programa de código aberto (gratuito) escrito em Javascript, você pode usar, copiar, modificar, combinar, publicar, distribuir, sublicenciar e ou vender cópias sem remover o autor principal deste bot.

 ➲Ao usar este bot, você concorda com os seguintes Termos e Condições:
  - O bot não armazena seus dados em nossos servidores.
  - O bot não é responsável pelos stickers que você faz desse bot, bem como pelos vídeos, imagens ou outros dados que você obtém dele.
  - Os bots não podem ser usados ​​para serviços que visam / contribuem para:
      • sexo / tráfico humano
      • jogatina
      • comportamento viciante prejudicial
      • crime
      • violência (a menos que necessário para proteger a segurança pública)
      • queima / desmatamento florestal
      • discurso de ódio ou discriminação com base na idade, sexo, identidade de gênero, raça, sexualidade, religião, nacionalidade

 ➲ API da Web Baileys Typescript / Javascript WhatsApp: https://github.com/adiwajshing/baileys

 ➲ * LOVE BOT Pausa 5 SEGUNDOS PRA LER !!!! *

 ➲ \ `\` \ `Este bot não está completamente concluído \` \ `\`
     \ `\` \ `Ainda em andamento \` \ `\`
      \ `\` \ `Portanto, raramente é ativo, e \` \ `\`
  .  . \ `` \ `\` Desculpe se há um menu de erro \ `\` \ `
 
 ➲ \ `\` \ `Se long, por favor, repita o comando \` \ `\`

 ➲ * Use o comando sem [] *

 ➲ \ `\` \ `E se você tiver erro \` \ `\`
     \ `\` \ `Informe o proprietário por \` \ `\`
 ➲ * relatório $ {prefix} * \ `\` \ `qual é a mensagem de erro \` \ `\`

 ➲ \ `\` \ `Você quer o ajudar o Bot ??  Doe, \ `` \ `
     \ `` \ `` Se você doar, siga Ig \ `\` \ `
      \ `\` \ `@memes_tataco\` \ `\`

 ➲ \ `` \ `` Você pode publicar suas citações \ `` \ `\`
  \ `\` \ `Se os interesses entrarem em contato com o proprietário Aja, crie \` \ `\`
   \ `\` \ `Publicar \` \ `\`
    \ `\` \ `` Suas cotações, \ `\` \ `
     \ `\` \ `E obrigado pelo amigo`` Quem Quer Estar em Público \ '' \ `\`
 .  \ `\` \ `A citação :) \` \ `\`

 ➲ \ `\` \ `Por que adiciono recursos premium \` \ `\`
 .. \ `\` \ `Você sabe por causa desses recursos \` \ `\`
    \ `` \ `\` Requer grande tempo para fazer o download \ `\` \ `
     \ `\` \ `E transmitir áudio / vídeo \` `\`
      \ `\` \ `Você doando por favor, ajuda demais 🙂 \` \ `\`
`
}
exports.rules = rules
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

const donasi = (Ig, name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DOAR o mais rápido possível:)* ❉⊰━━✿
┃  
┣━⊱ *DANA*
┣⊱ HUBUNGI OWNER AJA
┣━⊱ *PULSA*
┣⊱ HUBUNGI OWNER AJA
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY ANJOS MODS*
┗━━━━━━━━━━━━━━━━━━━━
Note:
Jika Gamau Donasi Setidaknya Follow IG Ngab:D
Kalo Dah Donasi Silahkan Invit Di Group Kalian:)
Makasih:)

PENGGANTI DONASI GAN!!!
https://youtube.com/c/FadhilGraphy
${Ig}

`
}

exports.donasi = donasi

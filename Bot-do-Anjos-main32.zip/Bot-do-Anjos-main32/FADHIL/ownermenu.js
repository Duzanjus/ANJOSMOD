const ownermenu = (prefix) => { 
	return ` 
	
╭──「 *SÓ O ANJOS PODE USAR* 」───
│
├➲ *${prefix}addprem [mentioned]*
├➲ *${prefix}removeprem [mention]*
├➲ *${prefix}setppbot*
├➲ *${prefix}setreply*
├➲ *${prefix}bc*
├➲ *${prefix}bcgc*
├➲ *${prefix}ban*
├➲ *${prefix}unban*
├➲ *${prefix}block*
├➲ *${prefix}unblock*
├➲ *${prefix}clearall*
├➲ *${prefix}delete*
├➲ *${prefix}clone*
├➲ *${prefix}getses*
├➲ *${prefix}leave*
│
╰──────────────────
	
            *©ANJOS MODS*
╲    ╱    ● ᏴϴͲ●ᎷᎬΝႮ●
       ╱▔▔▔▔▔╲       Autor    : ANJOS
      ┃┈▇┈┈▇┈┃      
╭╮┣━━━━━━┫╭╮    
┃┃┃┈┈┈┈┈┈┃┃┃    
╰╯┃┈┈┈┈┈┈┃╰╯
      ╰┓┏━━┓┏╯
         ╰╯      ╰╯`
	}
exports.ownermenu = ownermenu

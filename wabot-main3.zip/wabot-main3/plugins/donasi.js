let handler = async m => m.reply(`
╭─「 Doação • Pulso • Gopay • Fundo 」
│ • PICPAY [5511932300710]
│ • PIX [5511932300710]
│ • PICPAY [5511932300710]
╰────
`.trim()) // Adicione você mesmo se quiser
handler.help = ['donasi']
handler.tags = ['info']
handler.command = /^dona(te|si)$/i

module.exports = handler

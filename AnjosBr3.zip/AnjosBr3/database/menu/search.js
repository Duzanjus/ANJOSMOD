const search = (pushname, prefix, botName, ownerName) => {
	return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/5511932300710
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


                    *ANJOS*

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}wait*
║➩ ❍ *${prefix}ytsearch*
║➩ ❍ *${prefix}trendtwit*
║➩ ❍ *${prefix}wikien*
║➩ ❍ *${prefix}wiki*
║➩ ❍ *${prefix}neonime*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.search = search

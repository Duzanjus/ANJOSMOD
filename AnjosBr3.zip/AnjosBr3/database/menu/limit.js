const limit = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/5511932300710
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


                     *ANJOS* 

───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}buylimit*
║➩ ❍ *${prefix}bal*
║➩ ❍ *${prefix}limit*
║➩ Aumente seu level interagindo no grupo!!
───────⊹⊱✫⊰⊹───────`
}
exports.limit = limit

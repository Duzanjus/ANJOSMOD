const iklan = () => { 
	return `           
╔══✪〘 PROPAGANDA 〙✪══
║
╠═══════════════════════════
╠➥ *REGISTE-SE PARA USAR E FAZER PARTE :*
╠➥ *PREMIUM/VIP : ENTRAR EM CONTATO COM O ANJOS (5 REAIS)
╠═══════════════════════════
╠➥ *AMBOS TEREMOS LUCRO :*
╠➥ *1. PODE OBTER COMANDO ADMIN*
╠➥ *BENEFÍCIOS PARA  VIPS :*
╠➥ *1. PODE SER PROPRIETÁRIO DO BOT *
╠➥ * 2. PODE ALTERAR O NOME DO PRÓPRIO BOT *
╠➥ * 3. PODE TRAZER BOTS PARA O GRUPO *
╠➥ * 4. PODE USAR O COMANDO DO DONO:*
╠═══════════════════════════
╠➥ *EM CASO DE PUBLICIDADE DE INTERESSE *
╠➥ * ENTRE EM CONTATO COM O NÚMERO ABAIXO: *
╠➥ *https://api.whatsapp.com/send?phone=5511932300710*
║
╚═〘  ANJOS BOT〙


`
}
exports.iklan = iklan
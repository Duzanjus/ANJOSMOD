const daftarvip = (prefix) => { 
	return `
	
*HARGA DAFTAR VIP :*
-Rp. 10K > Akses Fitur ViP
-Rp. 20K > Fitur VIP + Masukin Bot KeGrup Kalian!

*JIKA INGIN DAFTAR VIP :*
*Chat Owner BOT :*
_wa.me/18313535216  atau ketik *${prefix}owner*

*NOTE*

JANGAN LUPA SUBSCRIBE CHANNEL MR KING
`
}
exports.daftarvip = daftarvip
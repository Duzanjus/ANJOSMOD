const tnc = () => { 
	return `       
	O código-fonte / bot é um programa de código aberto (gratuito) escrito usando Javascript, você pode usar, copiar, modificar, combinar, publicar, distribuir, sublicenciar
Ao usar este código-fonte / bot, você concorda com os seguintes Termos e Condições:
- O código-fonte / bot não armazena seus dados em nossos servidores.
Este bot é gratuito, você pode fazê-lo, verifique a produção do yt dev anker
- O código-fonte / bot não é responsável pelos adesivos que você faz a partir deste bot e vídeos, imagens ou outros dados
    • sexo / tráfico humano
    • jogatina
    • comportamento viciante prejudicial
    • crime
    • violência (a menos que necessário para proteger a segurança pública)
    • queima / desmatamento florestal
    • discurso de ódio ou discriminação com base na idade, sexo, identidade de gênero, raça, sexualidade, religião, nacionalidade`
    }
exports.tnc = tnc

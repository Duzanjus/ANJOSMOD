const gemini = () => { 
	return `       
Gêmeos (21 de maio a 20 de junho)

Gêmeos (♊) [1] é o terceiro signo da constelação de Gêmeos. Sob o zodíaco tropical, o sol transita por este signo entre 21 de maio e 21 de junho. Gêmeos é representado pelos gêmeos Castor e Pollux. [2] Este símbolo de gêmeos é baseado nos Dioscuri, dois humanos que recebem poderes divinos conjuntos após sua morte.
`
}
exports.gemini = gemini
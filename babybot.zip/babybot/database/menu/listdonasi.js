const listdonasi = (pushname, prefix, botName, ownerName, getLevelingLevel, sender, _registered) => {
	return `❀:ཻུ۪۪⸙ -----[ *IKLAN DULU GAYS* ]----- ❀:ཻུ۪۪⸙
Hallo, ${pushname} 👋
Semoga harimu Menyenangkan User, ${sender.split("@")[0]}
╭════〘 *IKY BOT* 〙══════⊱❁۪۪۪
┃□╭─────────────────
┃□│⊱❥ NAMA : ${pushname}
┃□│⊱❥ LEVEL : ${getLevelingLevel(sender)}
┃□│⊱❥ USER ${botName} : ${_registered.length}
┃□╰─────────────────
╰════════════════════⊱❁۪۪۪
 ✎┊ ⊱❥ *THX DONATE TO*
╭════════════════════⊱❁۪۪۪
┃⊱❥ *@6285718038935(suci)*
┃⊱❥ insta:@Suci_rama91
┃⊱❥ *@6282143693807(sherly)*
┃⊱❥ insta:@ff.sherly
┃⊱❥ *@6281215956229(farhan)*
┃⊱❥ insta:@flaxa_rhanmaru
┃⊱❥ *@62895332982014(icha)*
┃⊱❥ insta:lussyaichaa_
┃⊱❥ *KALIAN DONASI YA👍*
╰════════════════════⊱❁۪۪۪


❀:ཻུ۪۪⸙ -----[ *POWERED BY ${ownerName}* ]----- ❀:ཻུ۪۪⸙`
}
exports.listdonasi = listdonasi
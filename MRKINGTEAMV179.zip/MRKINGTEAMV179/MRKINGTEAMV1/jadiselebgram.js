const jadiselebgram = () => { 
	return `           

☾ *ANJOS BOT!* ☽

🏿 🏾 🏽 🏼 🏻

Para quem quer aderir a Opção vip por favor escolha, quer o grátis, ou o Vip? 😍

Então, quais são os benefícios de se tornar vip?  a diferença é simples: você tem direito a recursos que a gratuita não tem

Então, para aqueles que ainda estão em dúvida, você pode simplesmente participar de graça primeiro 😘

✩‧₊˚ A. FILTRO P/ MEMBROS GRATIS : 0 Reais
╭┈────────────────🧊ˊˎ-
│🍯  PARTICIPAR DO GRUPO
│🍯  USAR COMANDOS
│🍯  ORIENTAÇÃO COMPLETA
│🍯  UTILIZANDO COM SUCESSO
╰─ 


✩‧₊˚ B. FILTRO PRA MEMBROS VIP : 5 reais
╭┈────────────────🧊ˊˎ-
│🍯 ENVIE PARA UMA CONTA DO DONO: ANJOS
│🍯 EMBLEMAS DE MEMBROS
│🍯 ORIENTAÇÃO COMPLETA
│🍯 UTILIZA RECURSOS VIP
│🍯 BÔNUS APK FULL PACK!
╰─

║▌│█║▌│ █║▌│█│║▌║
*Então você quer escolher qual ☺️*
*Clique no link abaixo se quiser falar com o Dono: 🥰*
https://wa.me/5511932300710?text=*Anjos*~~kak..%20%0ASaya%20Mau%20Join%20*Bisnis+member+Selebgram%20Yang%20Lagi+viral+itu*%20Boleh%20liat%20Menu%20pilihannya+kak%20
║▌│█║▌│ █║▌│█│║▌║
`
}
exports.jadiselebgram = jadiselebgram
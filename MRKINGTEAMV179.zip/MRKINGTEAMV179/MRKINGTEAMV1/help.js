const help = (prefix) => {
        return `
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ SOBRE O BOTꪶ ཻུ۪۪ꦽꦼ̷⸙•═══╮
┣⊱ *Nome : ©ANJOS BOT 
┣⊱ *Versão : V1. 0.0*
┣⊱ *Status : ATIVO*
┣⊱ *Proprietário : ANJOS
┣⊱ *Total : 603 RECURSOS*
┣⊱ *Prefix : 「 ${prefix} 」*
╰═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ MR KING TEAM ཻུ۪۪ꦽꦼ̷⸙•═══╯
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  * MENU P/ CRIADOR DO BOT(ANJOS)* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}block 62858xxxxx*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}unblock 62858xxxxx*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}promote @tagmember*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}demote @tagadmin*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bc*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}leave*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bc2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bc3*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}leave*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kick*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}add*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}clearall*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}clone*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag3*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag50*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag20*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag5*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}setprefix*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}unban*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ban*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}banlist*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}runtime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tutuptime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}turnoff*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}getses*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}addadmin*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}public [1/0]*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *PARA ADMINISTRADORES DE GRUPO* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ban @tagmember*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}unban @tagmember*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}spamcall [81273xxxx]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kickall*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}leave*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}promote*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}demote*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}delete*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}add 62813xxxxx*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kickall*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tagall*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}otagall*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}otagall2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tagall*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}setdesc*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}setname*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kick* [tag]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kicktime [tag]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}add* [628xxx]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}promote* [tag]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}demote* [tag]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}group* [buka]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}group* [tutup]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}linkgc*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}setpp* [your]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}groupinfo*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tagme*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfw* [1/0]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}anime* [1/0]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}simih* [1/0]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}welcome* [1/0]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}edotensei*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}listadmins*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ping*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *JOGOS DIVERTIDOS* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tebakgambar*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}caklontong*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}family100*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}game*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}truth*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}dare*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pantun*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quotes*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}katakata*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hilih*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kiss*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}alay [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}simi [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bucin*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}peluk*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cium*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}say*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}addsay*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}resetsay*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}saylist*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}gtts [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tts* [kodebahasa]
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *COMANDOS DE MENU* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}apakah [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}rate [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bisakah [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kapankah [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}gantengcek*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}toxic*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bucin*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}katailham*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}citacita*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}afk*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}unafk*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cerpen*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hobby*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}watak*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cantikcek*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nilai [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}te*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ramalhp*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}primbonjodoh*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}slap*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}akugay*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cry*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}jadian*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nangis*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hunti*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}persengay*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *MENU P/ MEMBROS* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}reqwest [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}laporbug [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}infoalamat [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bugreport [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}apkmod*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}donasi*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tagme*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wame*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}speed*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ping*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}assalamualaikum*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}lirik [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}modroid [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}happymod [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bfont*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}textstyle*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}fitnah*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}jd*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pe*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}all*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}news*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}memobot*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cekup*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bycc*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}imagepest*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}qoutes*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}meme*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}memeindo*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hug
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}walpaperhd*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cekprefix*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}qrcode*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}shota*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}husbu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}husbu2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}covid*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}imoji*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *MENU DE CRIAÇÃO* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cslogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tahta [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tahta2 [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pronlogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}snow [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}marvelogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}mlogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}text3d [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}blackpink [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ninjalogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wolflogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}lionlogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}textscreen* [text
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}rtext [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}thunder [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}stiltext [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}party [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}galaxtext [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}lovemake [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}walpaperhd [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}watercolor [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quotemaker* [tx|tx|random]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}water [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}epep [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}glitch [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}fire [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wood [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ffbaner [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}light [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sandwriting [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}embuntext [text] *
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}textsky [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}textblue [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}textdark [text*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}apiteks [text*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quoteit [tx|tx|random]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}marvelogo [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}jokerlogo [teks]*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *MÍDIA & DOWLOAD MENU* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}yt* [link]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tiktok* [link]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ytsearch* [yt search]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}lirik* [judul lagu]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}chord* [judul lagu]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}igstalk [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wikien* [love]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tiktokstalk* [username]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tomp3*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}url2img* [link]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}fototiktok* [username]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}map* [kota]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kbbi* [kamus]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}brainly* [tau sendiri kan]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}infoghitub* 
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}infocuaca* [kota]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}infogempa*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}artinama [nama]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}covid [negara]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nulis [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sandwriting [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quotemaker [|teks|author|theme]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}resepmasakan [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tts [kode bhs] [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}igstalk [@username]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tiktokstalk [@username]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wiki [query]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}qrcode [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}map [optional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}textmaker [teks1|teks2]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ssweb [linkWeb]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}shorturl [linkWeb]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}image [opsional]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}animesaran*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}animesaran2*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *PARA MEMBRO VIP* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ytmp4 [link]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ytmp3 [link]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}joox [lagu]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}setprefix*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tomp3 [replay video]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomanime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomhentai*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwloli*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwblowjob*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwneko*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwtrap*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}indohot*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}otagall2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}otagall3*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hidetag5*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *NSFW MENU +18* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomhentai*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hentai*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cersex*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}xxx*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwblowjob*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwtrap*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwneko*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}loli*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nsfwloli*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bokep*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kodenuklir2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomanime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randombokep*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cry*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kiss*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomhug*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nekonime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}waifu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}waifu2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kodenuklir*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nenen*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}p*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cak*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pps*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}teus*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}walpaperanime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}animerandom*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nekopoi*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *OUTROS COMANDOS * 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sticker*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}stickergif*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ttp [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}toimg [replay sticker]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}neko*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pokemon*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}inu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}infoGempa*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quotes*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}dadu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quotes*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}thunder [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}nulis [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ocr [gambar]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}meme*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}memindo*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}testime*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}testing*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ttp [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hobby*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}beritahoax*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}watak*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}jsholat [daerah]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}jarak*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}report*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hilih [teks]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}cekjodoh* [nama]
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}chroman*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}artinama [text]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}listsurah*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}reminder*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}zodiak [zodiak kamu]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}listzodiak*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *ANIME MENU* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}miku*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ram*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}rem*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kurumi*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pictwaifu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pictlolicon*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}goku*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}dxd*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}itori*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}rize*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}minato*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}naruto*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}boruto*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}toukachan*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sakura*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sasuke*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hentai*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}waifu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}waifu2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wibu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}loli*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}loli4*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}waifu3*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quotesanime'*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}akira*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  * COMANDOS ANIMAIS* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomanimals*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}unta*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}kucing*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}binatang*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}elang*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}anjing*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pokemon*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}inu*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}animehug*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}ban*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomcat*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *DINHEIRO & LIMITE* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}limit*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}buylimit*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}transfer*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}atm*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bal (SOON)*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}rank (SOON)*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}mining*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}event [1/0]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}resetlimit*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *ISLAMISMO MENU* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}quran*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}jsholat [daerah]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}murrotal [surah]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sholawat [judul]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}videodakwah [hukum memakai cadar]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}listsurah*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *SOUND MENU* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tupai [nominal]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bass [nominal]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}gemuk [nominal]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}fast [nominal]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}slow [nominal]*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *MENU DE EFEITOS* 🌈✨
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}iri*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pale*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}dj1*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}dj2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound2*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound3*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound4*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound5*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound6*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sound7*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}baka*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *ESCOPO MENU* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}tiktok*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}wolfmetal*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}mutgrass*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}randomkpop*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}run*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}resepmasakan*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}xd*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}emailtome*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}aguse*
├  ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}qowhea*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *SPAM MENU🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}spamcall [822××××]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}spamchat [822××××]*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}spamgmail [gmail]*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙
╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙──
┣⊱  *FERRAMENTAS P/ HACKING* 🌈✨
│
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}darkfb*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}hackfb*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}bruteforcefb*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}pluginactive*
├ ♡ۣۜۜ፝͜͜͡͡✿➤ *${prefix}sreenfetch*
╰═════ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙

╭═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙═══╮
┣⊱   *OBRIGADO POR USAR DE:* 🌈✨
│
│ *ꔷ㆒᮫ᨗ᪼᠂⃟🦖ANJOSꪶ᭢*
│
╰═══•›ꪶ ཻུ۪۪ꦽꦼ̷⸙ ━ ━ ━ ━ ꪶ ཻུ۪۪ꦽꦼ̷⸙═══╯

        ▉║█▐▉▉▐▐▍█║▍▉▏▍▍
        ▉║█▐▉▉▐▐▍█║▍▉▏▍▍   
                                        
                               
          *© ANJOS BOT*     
`
}
exports.help = help

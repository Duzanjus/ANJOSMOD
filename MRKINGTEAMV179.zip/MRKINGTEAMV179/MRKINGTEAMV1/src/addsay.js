const addsay = () => { 
	return `
	
	*ADD Message*
	
	Message  BEM SUCEDIDO SALVO EM DADOS!
	

Thanks !`
}
exports.addsay = addsay
const aries = () => { 
	return `       
Aries (21 Março – 20 abril)

Aries (♈) /ˈɛəriːz/ (que significa "Ovelha") é a primeira constelação do Zodíaco, que inclui os primeiros 30 graus de longitude (0 ° ≤ λ <30 °). Sob o zodíaco tropical, o Sol transita nesta constelação geralmente entre 20 de março e 20 de abril de cada ano. A duração desse tempo é exatamente o primeiro mês do calendário persa (Farvardin). Sob o signo do zodíaco sideral, o sol transita por Áries de 15 de abril a 15 de maio (aproximadamente). Um símbolo de ovelha baseado em Chrysomallus, a ovelha voadora.
Dependendo do sistema utilizado, os indivíduos nascidos nessa data podem ser chamados de arianos ou arianos . Áries é a primeira constelação de fogo do zodíaco, outras constelações de fogo são Leão e Sagitário
`
}
exports.aries = aries
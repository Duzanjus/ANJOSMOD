const cekvip = () => { 
	return `           
──────────────────
*Nome do bot* : ANJOS BOT
──────────────────
        『 *FEEDZ* 』
──────────────────
• *Status*    : *ATIVO*
────────────────── 
*Status Bot:* *Online*
────────────────── `
}
exports.cekvip = cekvip
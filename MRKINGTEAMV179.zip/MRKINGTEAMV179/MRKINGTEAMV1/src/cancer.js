const cancer = () => { 
	return `       
Cancer (21 Junho – 20 julho)

Câncer (♋) (grego antigo: Καρκίνος, latim: Câncer) é o quarto signo do zodíaco que vem da constelação de Câncer. Este signo do zodíaco inclui 90 ° a 120 ° do zodíaco, entre 90 ° e 120 ° do sistema de coordenadas celestes. Sob o zodíaco tropical, o Sol transita nesta área entre 22 de junho e 22 de julho e, abaixo da barra lateral, o Sol transita nesta área de 16 de julho a 15 de agosto.[1]
Na astrologia, Câncer é o signo cardinal do zodíaco do elemento água, que inclui Câncer, Pises e Escorpião. [2] Este signo do zodíaco tem energia negativa e vive no planeta Lua. O câncer tem a forma de um caranguejo, baseado em Karkinos, o caranguejo gigante que Hércules o assediou durante sua luta contra a Hidra.
`
}
exports.cancer = cancer
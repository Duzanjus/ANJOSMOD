function listzodiak() {
    return `
╔════「 *LISTA ZODIAK* 」
╠≽ Áries (21 de março a 20 de abril)
╠≽ Touro (21 de abril a 20 de maio)
╠≽ Gêmeos (21 de maio a 20 de junho)
╠≽ Câncer (21 de junho a 20 de julho)
╠≽ Leo (21 de julho a 21 de agosto)
╠≽ Virgem (22 de agosto a 22 de setembro)
╠≽ Libra (23 de setembro a 22 de outubro)
╠≽ Escorpião (23 de outubro a 22 de novembro)
╠≽ Sagitário (23 de novembro a 20 de dezembro)
╠≽ Capricórnio (21 de dezembro a 19 de janeiro)
╠≽ Aquário (20 de janeiro - 18 de fevereiro)
╠≽ Peixes (19 de fevereiro a 20 de março)
╚════ #listzodiak *「 B O T 」* `
}
exports.listzodiak = listzodiak
const aries = () => { 
	return `       
Áries (21 de março a 20 de abril)

Áries (♈) / ˈɛəriːz / (significando "Cordeiro") é a primeira constelação do Zodíaco, que inclui os primeiros 30 graus de longitude (0 ° ≤ λ <30 °). Sob o zodíaco tropical, O sol transita nesta constelação geralmente entre 20 de março e 20 de abril de cada ano. A duração desse tempo é exatamente o primeiro mês do calendário persa (Farvardin). Sob o signo do zodíaco sideral, o sol transita por Áries de 15 de abril a 15 de maio (aproximadamente). Um símbolo de ovelha baseado em Chrysomallus, a ovelha voadora.
Dependendo do sistema usado, os indivíduos nascidos nessa data podem ser chamados de Arianos ou Ariens. Áries é a primeira constelação de fogo do zodíaco, as outras constelações de fogo são Leão e Sagitário
`
}
exports.aries = aries
const taurus = () => { 
	return `       
Touro (21 de abril - 20 anos)

Touro (latim para "touro"; símbolo:, Unicode: ♉) é o segundo signo astrológico do zodíaco. Zodíaco Este signo do zodíaco cobre o grau 30-60, entre 27,25 e 54,75 graus de longitude. Sob o zodíaco tropical, o sol transita nesta área de 20 de abril a 20 de maio de cada ano. Sob o zodíaco sideral, o sol transita pela constelação de Touro de 16 de maio a 21 de junho. Pessoas nascidas entre essas datas, dependendo do sistema astrológico escolhido, podem ser chamadas de taurinos.[1][2] O símbolo do touro é baseado no touro cretense, um touro branco, o pai do Minotauro que foi morto por Teseu.
`
}
exports.taurus = taurus
const gemini = () => { 
	return `       
Gêmeos (21 de maio a 20 de junho)

Gêmeos (♊) [1] é o terceiro signo da constelação de Gêmeos. Sob o zodíaco tropical, o sol transita por este signo entre 21 de maio e 21 de junho. Gêmeos é representado pelos gêmeos Castor e Pollux.[2] Este símbolo de gêmeos é baseado nos Dioscuri, dois humanos que recebem poderes divinos conjuntos após sua morte.
`
}
exports.gemini =gemini
const cancer = () => { 
	return `       
Câncer (21 de junho a 20 de julho)

Câncer (♋) (grego antigo: Καρκίνος, latim: Câncer) é o quarto signo do zodíaco que vem da constelação de Câncer. Este signo do zodíaco inclui 90 ° a 120 ° do zodíaco, entre 90 ° e 120 ° do sistema de coordenadas celestes. Sob o zodíaco tropical, o Sol transita nesta área entre 22 de junho e 22 de julho, e abaixo da barra lateral, O sol transitou nesta área de 16 de julho a 15 de agosto. [1]
Na astrologia, Câncer é o zodíaco cardeal do elemento água, que consiste em Câncer, Pises e Escorpião.[2] Este signo do zodíaco tem energia negativa e vive no planeta Lua. O câncer tem a forma de um caranguejo, baseado em Karkinos, o caranguejo gigante que Hércules o assediou durante sua luta contra a Hidra.
`
}
exports.cancer = cancer
const Leo = () => { 
	return `       
Leo (21 de julho a 21 de agosto)

Leão (♌) (grego antigo: Λέων, latim: Leōn), é o quinto signo do zodíaco, derivado da constelação de Leão. Aparece depois de Câncer (grego: Καρκίνος, latim: Karkinos) e antes de Virgem (grego: Παρθένος, latim: Parthenos). No zodíaco tropical, o Sol transita nesta constelação de 23 de julho a 22 de agosto;
`
}
exports.Leo = Leo
const Virgo = () => { 
	return `       
Virgem (22 de agosto a 22 de setembro)

Virgem (♍) (grego: Παρθένος, Partenos) é o signo astrológico de agudeza no Zodíaco. Este signo cobre 150-180 graus do zodíaco. Sob o zodíaco tropical, o Sol transita nesta área em média entre 23 de agosto e 22 de setembro,[1] e o Sol transita pela constelação de Virgem de cerca de 16 de setembro a 30 de outubro.
`
}
exports.Virgo = Virgo
const Libra = () => { 
	return `       
Libra (23 de setembro a 22 de outubro)

Libra (♎) é o sétimo signo do zodíaco. Este signo do zodíaco inclui 180 ° –210 ° de longitude.[1] No zodíaco tropical, o sol transita em 23 de setembro e 23 de outubro,[2][3] e no zodíaco sideral, o sol está nesta constelação de 31 de outubro a 22 de novembro. [4] O símbolo da balança neste zodíaco é baseado na Escala da Justiça mantida por Themis, a encarnação da lei da Grécia..[5] Ela se tornou a inspiração para a mulher legal moderna. O planeta que abriga Libra é Vênus.[6][7] Libras são os únicos signos do zodíaco representados com objetos não vivos. Outros signos do zodíaco são representados com animais ou criaturas mitológicas.
`
}
exports.Libra = Libra
const Scorpio = () => { 
	return `       
Escorpião (23 de outubro a 22 de novembro)

Escorpião (♏) (grego: Σκορπιός Skorpios; latim: Escorpião) é a oitava estrela na lista do zodíaco. Esta estrela está na ordem do zodíaco 210-240, entre 207,25 e 234,75 graus de longitude. Sob o zodíaco tropical, o sol transita nesta área em média entre 23 de outubro e 22 de novembro, e sob o zodíaco sideral, o sol está atualmente transitando pela constelação de Escorpião entre 16 de novembro e 15 de dezembro. Dependendo do sistema zodíaco usado, um indivíduo nascido sob a influência de um Escorpião pode ser chamado de Escorpião ou Escorpião..[1] O símbolo do escorpião é baseado em Scorpius, o escorpião gigante enviado por Gaia para matar Orion.[2]
Escorpião é o segundo signo de água, depois de Câncer e é seguido pelo terceiro signo de água, Peixes.
`
}
exports.Scorpio = Scorpio
const Sagittarius = () => { 
	return `       
Sagitário (23 de novembro a 20 de dezembro)

Sagitário (♐) é o nono signo do zodíaco na carta do zodíaco. No céu, este signo do zodíaco se estende entre 240 graus e 269 graus do sistema de coordenadas da eclíptica. No zodíaco tropical, o Sol transita nesta área de 23 de novembro a 21 de dezembro de cada ano. Na astrologia sideral, quando o sol transita na constelação de Sagitário por volta de 16 de dezembro a 14 de janeiro.
`
}
exports.Sagittarius = Sagittarius
const Capricorn = () => { 
	return `       
Capricórnio (21 de dezembro a 19 de janeiro)

Capricórnio é uma das constelações do zodíaco. Normalmente conhecido como Capricórnio, especialmente em astrologia. Esta constelação simboliza a cabra com chifres, embora às vezes muitos chamem de cabra do mar. Capricórnio é uma das 88 constelações modernas e também uma das 48 constelações listadas por Ptolomeu. Dentro dos limites das constelações modernas, esta constelação é cercada por Aquila, Sagittarius, Microscium, Piscis Austrinus e Aquarius.
No Zodíaco, os indivíduos que têm uma estrela de Capricórnio nascem de 22 de dezembro a 19 de janeiro, quando o Sol está na estrela de Capricórnio.
`
}
exports.Capricorn = Capricorn
const Aquarius = () => { 
	return `       
Aquário (20 de janeiro - 18 de fevereiro)

Aquário (♒) é o décimo primeiro dos doze signos do zodíaco astrológico e vem da constelação de mesmo nome, a constelação de Aquário.
Indivíduos nascidos quando o sol está neste signo são conhecidos como "indivíduos de Aquário". Aquário foi considerado o signo masculino do zodíaco pelos antigos astrólogos e foi colonizado pelo planeta Saturno, mas o planeta Urano é considerado o verdadeiro guardião de Aquário por vários astrólogos modernos. O nome sânscrito para Aquário na astrologia hindu é Kuṃbha.
`
}
exports.Aquarius = Aquarius
const Pisces = () => { 
	return `       
Peixes (19 de fevereiro a 20 de março)

Peixes (peixe) é uma constelação do signo do zodíaco entre Aquário a oeste e Áries a leste. Pises é o 12º símbolo astrológico do zodíaco, que vem da constelação de Pises. Na astrologia, Pises é sinônimo de símbolos femininos ou negativos. Também é um símbolo de água. No zodíaco é representado por um par de peixes nadando em direções opostas. Tradicionalmente, Pises reinou no planeta Júpiter, mas desde sua descoberta, Netuno tem sido o trono moderno deste emblema.
No Zodíaco, os indivíduos que têm uma estrela de Peixes nascem de 19 de fevereiro a 20 de março, quando o Sol está na estrela de Peixes.
`
}
exports.Pisces = Pisces
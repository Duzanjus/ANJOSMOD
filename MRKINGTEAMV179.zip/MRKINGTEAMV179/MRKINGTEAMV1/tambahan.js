module.exports = {
	halo: "ANJOS DOMINA 😎* \n\nexemplo *${prefix}menu* para exibir todos os recursos disponíveis \r\n\r\n \n \r",
	hai: "ANJOS DOMINA 😎*\n\n exemplo *${prefix}menumenu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	ass: "ANJOS DOMINA 😎*\n\n exemplo *${prefix}menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	bro: "ANJOS DOMINA 😎!!!* \n\nexemplo *${prefix}menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	p: "ANJOS DOMINA 😎*\n\n exemplo *${prefix}menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	test: "*ANJOS DOMINA 😎*\n\n exemplo *${prefix}menu* untuk menampilkan semua fitur yang ada \r\n\r\n \n \r",
	sbr: "ANJOS DOMINA 😎",
}
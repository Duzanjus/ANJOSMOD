const killerbee0 = (prefix) => { 

	return `

	*note:*
	❗ Se você desativar o recurso Killerbee \ n, será necessário desativar o recurso de boas-vindas, caso contrário? \nDaí o recurso Killerbee \n*Continuará ativo e não funcionará mesmo que tenha sido desativado*
	
	*kegunaan:*
	❗ *Então, esta função Killerbee, assim como a função de boas-vindas!* \n*cuma, Esta é a autenticação de terceiros, portanto, sua função é um tipo de phishing!* \n\n*Breve explicação, * O ponto é que cada pessoa que sai do grupo, o bot enviará relatórios falsos para o WhatsApp com 3 × relatórios falsos consecutivos \n\n*Esse recurso é adequado para ativação para pessoas que entram em seu grupo, quanto mais ele faz login, mais rápido sua conta do WhatsApp é banida!*



❌ *cara menonaktifkan*
*modelo : /killerbee <espaço> 0*
*exemplo : /killerbee 0*

✔️ *cara mengaktifkan*
*modelo : /killerbee(1) <sem espaços>*
*exemplo : /killerbee1*

`

}

exports.killerbee0 = killerbee0

